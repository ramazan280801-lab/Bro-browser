const { app, BrowserWindow, ipcMain, session, Menu, dialog, clipboard, shell, net } = require('electron');
const path = require('path');
const fs = require('fs');

const P = n => path.join(app.getPath('userData'), n);
const rd = (n, d) => { try { return JSON.parse(fs.readFileSync(P(n), 'utf8')); } catch { return d; } };
const wr = (n, v) => { try { fs.writeFileSync(P(n), JSON.stringify(v)); } catch {} };

const defaults = { shield: true, trackers: true, https: true, cookies: true, dnt: true, perms: true,
  banners: true, sleep: true, restore: true, speed: true, engine: 'ddg', theme: 'purple', zoom: 0 };
let S = { ...defaults, ...rd('settings.json', {}) };
let stats = rd('stats.json', { blocked: 0 });
let sessionBlocked = 0;
let extra = new Set();
let win;

const parseHosts = t => {
  const s = new Set();
  for (const l of t.split(/\r?\n/)) {
    const h = l.split('#')[0].trim().split(/\s+/).pop();
    if (h && h.includes('.') && !h.includes('/') && h !== 'localhost') s.add(h.toLowerCase());
  }
  return s;
};
try { extra = parseHosts(fs.readFileSync(P('hosts.txt'), 'utf8')); } catch {}

if (S.speed) {
  app.commandLine.appendSwitch('enable-gpu-rasterization');
  app.commandLine.appendSwitch('enable-zero-copy');
}
if (process.platform === 'linux' && process.env.APPIMAGE) app.commandLine.appendSwitch('no-sandbox');

const BAD = ['doubleclick.net', 'google-analytics.com', 'googletagmanager.com', 'googlesyndication.com',
  'connect.facebook.net', 'adservice.google.com', 'scorecardresearch.com', 'hotjar.com', 'criteo.com',
  'taboola.com', 'outbrain.com', 'adnxs.com', 'amazon-adsystem.com', 'mc.yandex.ru', 'mixpanel.com',
  'segment.io', 'quantserve.com', 'moatads.com', 'rubiconproject.com', 'pubmatic.com', 'openx.net',
  'adsrvr.org', 'bat.bing.com', 'clarity.ms', 'ads.twitter.com', 'analytics.tiktok.com'];

const on = k => S.shield && S[k];
const host = u => { try { return new URL(u).hostname; } catch { return ''; } };
const root = h => h.split('.').slice(-2).join('.');
const third = d => d.referrer && root(host(d.referrer)) !== root(host(d.url));
const send = (ch, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(ch, ...a); };
const isBad = h => {
  if (BAD.some(b => h === b || h.endsWith('.' + b))) return true;
  let d = h;
  while (d) { if (extra.has(d)) return true; const i = d.indexOf('.'); if (i < 0) return false; d = d.slice(i + 1); }
  return false;
};

const asked = new Map();
function protect(ses) {
  ses.webRequest.onBeforeRequest((d, cb) => {
    const h = host(d.url);
    if (on('trackers') && isBad(h)) { sessionBlocked++; stats.blocked++; return cb({ cancel: true }); }
    if (on('https') && d.url.startsWith('http://') && !/^(localhost|127\.|192\.168\.|10\.)/.test(h))
      return cb({ redirectURL: d.url.replace('http://', 'https://') });
    cb({});
  });
  ses.webRequest.onBeforeSendHeaders((d, cb) => {
    const hd = d.requestHeaders;
    if (on('dnt')) { hd.DNT = '1'; hd['Sec-GPC'] = '1'; }
    if (on('cookies') && third(d)) delete hd.Cookie;
    cb({ requestHeaders: hd });
  });
  ses.webRequest.onHeadersReceived((d, cb) => {
    const hd = d.responseHeaders;
    if (on('cookies') && third(d)) for (const k of Object.keys(hd)) if (k.toLowerCase() === 'set-cookie') delete hd[k];
    cb({ responseHeaders: hd });
  });
  ses.setPermissionRequestHandler((wc, perm, cb, det) => {
    if (['fullscreen', 'pointerLock', 'clipboard-sanitized-write'].includes(perm)) return cb(true);
    const what = { media: 'камере и микрофону', geolocation: 'геолокации', notifications: 'уведомлениям', 'clipboard-read': 'буферу обмена' }[perm];
    if (!what || !S.perms) return cb(false);
    const o = host(det.requestingUrl || ''), key = o + perm;
    if (asked.has(key)) return cb(asked.get(key));
    dialog.showMessageBox(win, { type: 'question', buttons: ['Разрешить', 'Запретить'], defaultId: 1, cancelId: 1,
      message: (o || 'Сайт') + ' просит доступ к ' + what }).then(r => { const ok = r.response === 0; asked.set(key, ok); cb(ok); });
  });
  ses.on('will-download', (e, item) => {
    let p = path.join(app.getPath('downloads'), item.getFilename());
    if (fs.existsSync(p)) p = path.join(app.getPath('downloads'), Date.now() + '-' + item.getFilename());
    item.setSavePath(p);
    item.once('done', (_, st) => send('toast', st === 'completed' ? 'Скачано: ' + path.basename(p) : 'Ошибка загрузки'));
  });
}

const KEYS = i => {
  const c = i.control || i.meta, s = i.shift, k = i.key.toLowerCase();
  if (i.alt && !c) { if (k === 'arrowleft') return 'back'; if (k === 'arrowright') return 'fwd'; }
  if (k === 'f5') return 'reload';
  if (k === 'f11') return 'fullscreen';
  if (!c) return null;
  if (s && k === 'n') return 'incog';
  if (s && k === 'tab') return 'prev';
  return { tab: 'next', t: 'newtab', w: 'close', l: 'url', f: 'find', d: 'bookmark', h: 'history', r: 'reload',
    '+': 'zin', '=': 'zin', '-': 'zout', '0': 'zreset' }[k] || null;
};

app.on('web-contents-created', (e, wc) => {
  wc.setWindowOpenHandler(({ url }) => { send('open', url); return { action: 'deny' }; });
  wc.on('before-input-event', (ev, i) => {
    if (i.type !== 'keyDown') return;
    const a = KEYS(i); if (!a) return;
    ev.preventDefault();
    if (a === 'fullscreen') win.setFullScreen(!win.isFullScreen()); else send('shortcut', a);
  });
  if (wc.getType() === 'webview') {
    wc.on('enter-html-full-screen', () => win.setFullScreen(true));
    wc.on('leave-html-full-screen', () => win.setFullScreen(false));
    wc.on('context-menu', (ev, p) => {
      const t = [];
      if (p.linkURL) t.push(
        { label: 'Открыть в новой вкладке', click: () => send('open', p.linkURL) },
        { label: 'Открыть в инкогнито', click: () => send('open-incog', p.linkURL) },
        { label: 'Копировать ссылку', click: () => clipboard.writeText(p.linkURL) });
      if (p.mediaType === 'image' && p.srcURL) t.push(
        { label: 'Сохранить картинку', click: () => wc.downloadURL(p.srcURL) },
        { label: 'Копировать адрес картинки', click: () => clipboard.writeText(p.srcURL) });
      if (p.selectionText) t.push({ role: 'copy', label: 'Копировать' },
        { label: 'Искать в интернете', click: () => send('search', p.selectionText) });
      if (p.isEditable) t.push({ role: 'paste', label: 'Вставить' });
      t.push({ type: 'separator' }, { label: 'Назад', click: () => wc.goBack() },
        { label: 'Вперёд', click: () => wc.goForward() }, { label: 'Обновить', click: () => wc.reload() });
      Menu.buildFromTemplate(t).popup();
    });
  }
});

function createWindow() {
  win = new BrowserWindow({ width: 1280, height: 800, minWidth: 700, minHeight: 480, backgroundColor: '#15101f',
    title: 'Bro Browser', icon: path.join(__dirname, 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true, sandbox: false } });
  Menu.setApplicationMenu(null);
  win.loadFile('index.html');
  win.webContents.once('did-finish-load', () => {
    const u = process.argv.find(a => /^https?:\/\//.test(a));
    if (u) send('open', u);
  });
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', (e, argv) => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
    const u = argv.find(a => /^https?:\/\//.test(a));
    if (u) send('open', u);
  });
  app.whenReady().then(() => {
    protect(session.fromPartition('persist:bro'));
    protect(session.fromPartition('incog'));
    createWindow();
  });
}

ipcMain.handle('cfg:get', () => ({ S, blocked: stats.blocked, session: sessionBlocked, hosts: extra.size + BAD.length, ver: app.getVersion() }));
ipcMain.handle('cfg:set', (e, k, v) => { if (k in defaults) { S[k] = v; wr('settings.json', S); } return S; });
ipcMain.handle('data:get', (e, n) => rd(n + '.json', []));
ipcMain.handle('data:set', (e, n, v) => { if (['bookmarks', 'history', 'session'].includes(n)) wr(n + '.json', v); });
ipcMain.handle('lists:update', () => new Promise(res => {
  const r = net.request('https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext');
  const ch = [];
  r.on('response', rs => {
    rs.on('data', c => ch.push(c));
    rs.on('end', () => {
      const txt = Buffer.concat(ch).toString('utf8'), s = parseHosts(txt);
      if (s.size > 100) { fs.writeFileSync(P('hosts.txt'), txt); extra = s; res(s.size); } else res(0);
    });
  });
  r.on('error', () => res(0));
  r.end();
}));
ipcMain.handle('pdf:save', async (e, data) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: 'page.pdf', filters: [{ name: 'PDF', extensions: ['pdf'] }] });
  if (!r.canceled) fs.writeFileSync(r.filePath, Buffer.from(data));
  return !r.canceled;
});
ipcMain.handle('bm:export', async (e, list) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: 'bro-bookmarks.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (!r.canceled) fs.writeFileSync(r.filePath, JSON.stringify(list, null, 2));
});
ipcMain.handle('bm:import', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'JSON', extensions: ['json'] }], properties: ['openFile'] });
  if (r.canceled) return null;
  try { const l = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8')); return Array.isArray(l) ? l.filter(x => x && x.u) : null; } catch { return null; }
});
ipcMain.handle('incog:clear', async () => { const s = session.fromPartition('incog'); await s.clearStorageData(); await s.clearCache(); });
ipcMain.handle('data:clear', async () => { const s = session.fromPartition('persist:bro'); await s.clearStorageData(); await s.clearCache(); });
ipcMain.handle('dl:open', () => shell.openPath(app.getPath('downloads')));
app.on('before-quit', () => wr('stats.json', stats));
app.on('window-all-closed', () => app.quit());
