const { contextBridge, ipcRenderer: r } = require('electron');
const on = ch => fn => r.on(ch, (e, ...a) => fn(...a));
contextBridge.exposeInMainWorld('bro', {
  cfg: () => r.invoke('cfg:get'), set: (k, v) => r.invoke('cfg:set', k, v),
  get: n => r.invoke('data:get', n), put: (n, v) => r.invoke('data:set', n, v),
  updateLists: () => r.invoke('lists:update'), savePdf: d => r.invoke('pdf:save', d),
  exportBm: l => r.invoke('bm:export', l), importBm: () => r.invoke('bm:import'),
  clearIncog: () => r.invoke('incog:clear'), clearData: () => r.invoke('data:clear'),
  openDownloads: () => r.invoke('dl:open'),
  onOpen: on('open'), onOpenIncog: on('open-incog'), onSearch: on('search'),
  onToast: on('toast'), onShortcut: on('shortcut')
});
