package app.bro.browser

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.ProfileStore
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

class Tab(
    val web: WebView, val box: SwipeRefreshLayout, val incognito: Boolean,
    var title: String, var desktop: Boolean = false
)

class MainActivity : Activity() {
    private var BG = 0; private var BAR = 0; private var HI = 0; private var V = 0; private var INC = 0
    private val MUTED = Color.parseColor("#9D93B8")
    private val DIALOG = android.R.style.Theme_DeviceDefault_Dialog_Alert
    private val DESK = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val BANNER_JS = "(function(){var s=document.createElement('style');s.textContent='#onetrust-consent-sdk,#CybotCookiebotDialog,#didomi-host,.fc-consent-root,.cc-window,.cookie-banner,.cookie-consent,#cookie-banner,#cookieConsent,.truste_overlay,.adsbygoogle,ins.adsbygoogle,[id^=google_ads],.ad-banner,.ad-container,.advert,.ads-banner,[id^=yandex_rtb],.yandex-adv{display:none!important}html,body{overflow:auto!important}';document.head.appendChild(s)})()"
    private val READER_JS = "(function(){var a=document.querySelector('article')||document.querySelector('main')||document.body;var d=document.createElement('div');var t=document.createElement('h1');t.textContent=document.title;d.appendChild(t);a.querySelectorAll('h2,h3,p,img').forEach(function(e){var n;if(e.tagName=='IMG'){if(e.width<200)return;n=document.createElement('img');n.src=e.src;n.style.maxWidth='100%'}else{var x=e.innerText.trim();if(e.tagName=='P'&&x.length<25)return;n=document.createElement(e.tagName);n.textContent=x}d.appendChild(n)});document.body.innerHTML='';document.body.appendChild(d);document.body.style.cssText='max-width:680px;margin:0 auto;padding:20px;font:19px/1.6 Georgia,serif;background:#15101f;color:#e9e4f5'})()"

    private val tabs = mutableListOf<Tab>()
    private var cur: Tab? = null
    private lateinit var bar: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var urlBar: EditText
    private lateinit var shieldBtn: TextView
    private lateinit var countBtn: TextView
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("bro", MODE_PRIVATE) }
    private val blockedSession = AtomicInteger(0)
    @Volatile private var extra: Set<String> = emptySet()
    private var dx0 = 0f
    private var dy0 = 0f
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null
    private var pendingGeo: Pair<String, GeolocationPermissions.Callback>? = null
    private var pendingUrl: String? = null
    private val keys = listOf("shield", "trackers", "https", "cookies", "dnt", "sleep", "safe", "banners", "dark", "lock", "restore")
    private val names = listOf(
        "Bro Shield (главный выключатель)", "Блокировка трекеров и рекламы", "Только HTTPS",
        "Блокировать сторонние cookies", "Не отслеживать (DNT)", "Спящие вкладки", "Безопасный просмотр",
        "Скрывать баннеры cookies и рекламные блоки", "Тёмный режим для сайтов", "Замок на инкогнито (PIN или отпечаток)", "Восстанавливать вкладки при запуске"
    )
    private val bad = listOf(
        "doubleclick.net", "google-analytics.com", "googletagmanager.com", "googlesyndication.com",
        "connect.facebook.net", "adservice.google.com", "scorecardresearch.com", "hotjar.com", "criteo.com",
        "taboola.com", "outbrain.com", "adnxs.com", "amazon-adsystem.com", "mc.yandex.ru", "mixpanel.com",
        "segment.io", "quantserve.com", "moatads.com", "rubiconproject.com", "pubmatic.com", "openx.net",
        "adsrvr.org", "bat.bing.com", "clarity.ms", "ads.twitter.com", "analytics.tiktok.com"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun pref(k: String) = prefs.getBoolean(k, k != "dark" && k != "lock")
    private fun on(k: String) = pref("shield") && pref(k)
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { f() }
    }
    private fun engine() = prefs.getString("engine", "ddg") ?: "ddg"
    private fun engineName() = if (engine() == "google") "Google" else "DuckDuckGo"
    private fun shown(u: String?) = if (u == null || u.startsWith("file:")) "" else u
    private fun mi(t: String, f: () -> Unit) = t to f
    private fun menu(title: String, vararg items: Pair<String, () -> Unit>) {
        AlertDialog.Builder(this, DIALOG).setTitle(title)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second.invoke() }.show()
    }

    private fun loadTheme() {
        val t = when (prefs.getString("theme", "purple")) {
            "blue" -> arrayOf("#0E1420", "#151D2E", "#223049", "#3B82F6", "#1E3A8A")
            "green" -> arrayOf("#0F1914", "#14241C", "#1F3A2D", "#22C55E", "#14532D")
            "black" -> arrayOf("#000000", "#0A0A0A", "#1C1C1C", "#A78BFA", "#2A1B4D")
            else -> arrayOf("#15101F", "#1E1730", "#2B2145", "#8B5CF6", "#33205C")
        }
        BG = Color.parseColor(t[0]); BAR = Color.parseColor(t[1]); HI = Color.parseColor(t[2])
        V = Color.parseColor(t[3]); INC = Color.parseColor(t[4])
    }

    // ---------- данные ----------
    private fun load(k: String): MutableList<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val a = JSONArray(prefs.getString(k, "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(o.getString("t") to o.getString("u")) }
        } catch (e: Exception) { }
        return out
    }
    private fun save(k: String, l: List<Pair<String, String>>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        prefs.edit().putString(k, a.toString()).apply()
    }
    private fun addHistory(title: String, url: String) {
        val l = load("hist"); l.removeAll { it.second == url }; l.add(0, title to url)
        save("hist", l.take(200))
    }
    private fun home(inc: Boolean): String {
        val a = JSONArray()
        if (!inc) load("bm").take(8).forEach { a.put(JSONArray().put(it.first).put(it.second)) }
        return "file:///android_asset/newtab.html?e=" + engine() + "&i=" + (if (inc) 1 else 0) +
            "&l=" + URLEncoder.encode(a.toString(), "UTF-8")
    }
    private fun purge() {
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE))
                ProfileStore.getInstance().deleteProfile("incognito")
        } catch (e: Exception) { }
    }

    // ---------- списки блокировки ----------
    private fun parseHosts(t: String): Set<String> {
        val s = HashSet<String>()
        t.lineSequence().forEach { line0 ->
            val line = line0.substringBefore('#').trim()
            if (line.isEmpty()) return@forEach
            val h = line.split(Regex("\\s+")).last()
            if (h.contains('.') && !h.contains('/') && h != "localhost") s.add(h.lowercase())
        }
        return s
    }
    private fun loadHosts() {
        Thread {
            try { val f = File(filesDir, "hosts.txt"); if (f.exists()) extra = parseHosts(f.readText()) } catch (e: Exception) { }
        }.start()
    }
    private fun updateLists() {
        toast("Загружаю списки…")
        Thread {
            try {
                val c = URL("https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 20000
                val txt = c.inputStream.bufferedReader().readText()
                val s = parseHosts(txt)
                if (s.size > 100) {
                    File(filesDir, "hosts.txt").writeText(txt); extra = s
                    runOnUiThread { toast("Готово: " + s.size + " доменов") }
                } else runOnUiThread { toast("Список пустой") }
            } catch (e: Exception) { runOnUiThread { toast("Не удалось загрузить") } }
        }.start()
    }
    private fun blocked(h: String): Boolean {
        if (bad.any { h == it || h.endsWith(".$it") }) return true
        var d = h
        while (true) {
            if (extra.contains(d)) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    // ---------- жизненный цикл ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        loadTheme(); loadHosts(); purge()
        window.statusBarColor = BG; window.navigationBarColor = BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); fitsSystemWindows = true }
        urlBar = EditText(this).apply {
            hint = "Поиск или адрес"; setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 15f
            setSingleLine(); background = round(HI, 20); setPadding(dp(16), 0, dp(16), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); true }
        }
        shieldBtn = btn("🛡") {
            val v = !pref("shield")
            prefs.edit().putBoolean("shield", v).apply(); applyPrefs()
            toast(if (v) "Bro Shield включён" else "Bro Shield выключен")
        }
        countBtn = btn("1") { showTabs() }.apply {
            textSize = 13f; setPadding(dp(9), dp(3), dp(9), dp(3))
            background = GradientDrawable().apply { setStroke(dp(2), Color.WHITE); cornerRadius = dp(6).toFloat() }
        }
        bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(BAR); setPadding(dp(8), dp(6), dp(4), dp(6)) }
        bar.addView(urlBar, LinearLayout.LayoutParams(0, dp(42), 1f))
        bar.addView(shieldBtn)
        bar.addView(countBtn, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), 0, dp(4), 0) })
        bar.addView(btn("⋮") { showMenu() })
        root.addView(bar)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(V); visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val saved = load("session")
        if (intent?.dataString == null && pref("restore") && saved.isNotEmpty()) saved.take(8).forEach { newTab(it.second) }
        else newTab(intent?.dataString)
        if (intent?.action == "app.bro.INCOGNITO") openIncognito()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == "app.bro.INCOGNITO") openIncognito()
        else intent?.dataString?.let { newTab(it) }
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putLong("blocked", prefs.getLong("blocked", 0) + blockedSession.getAndSet(0)).apply()
        saveSession()
    }

    private fun saveSession() {
        val l = tabs.filter { !it.incognito }.mapNotNull { t ->
            val u = t.web.url ?: return@mapNotNull null
            if (u.startsWith("http")) t.title to u else null
        }
        save("session", l)
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx0 = e.rawX; dy0 = e.rawY }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - dx0; val dy = e.rawY - dy0
                if (abs(dx) > dp(110) && abs(dy) < dp(50)) {
                    val r = Rect(); bar.getGlobalVisibleRect(r)
                    val sw = resources.displayMetrics.widthPixels
                    if (r.contains(dx0.toInt(), dy0.toInt()) && !urlBar.hasFocus()) {
                        val i = tabs.indexOf(cur) + (if (dx < 0) 1 else -1)
                        if (i in tabs.indices) select(tabs[i])
                    } else if (dx0 < dp(20) && dx > 0) {
                        cur?.web?.let { if (it.canGoBack()) it.goBack() }
                    } else if (dx0 > sw - dp(20) && dx < 0) {
                        cur?.web?.let { if (it.canGoForward()) it.goForward() }
                    }
                }
            }
        }
        return super.dispatchTouchEvent(e)
    }

    // ---------- вкладки ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String? = null, incognito: Boolean = false) {
        val w = WebView(this)
        if (incognito) {
            try {
                if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE))
                    WebViewCompat.setProfile(w, "incognito")
                else Toast.makeText(this, "Обнови Android System WebView для полной изоляции инкогнито", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { }
            w.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        }
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.setBackgroundColor(BG)
        val box = SwipeRefreshLayout(this)
        box.setColorSchemeColors(V)
        box.setProgressBackgroundColorSchemeColor(BAR)
        box.addView(w, ViewGroup.LayoutParams(-1, -1))
        box.setOnRefreshListener { w.reload() }
        val t = Tab(w, box, incognito, if (incognito) "Инкогнито" else "Новая вкладка")
        w.setDownloadListener { u, ua, cd, mime, _ -> download(u, ua, cd, mime) }
        w.setOnLongClickListener {
            val h = w.hitTestResult
            val x = h.extra
            if (x == null) false
            else when (h.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> { linkMenu(x, false); true }
                WebView.HitTestResult.IMAGE_TYPE -> { linkMenu(x, true); true }
                else -> false
            }
        }
        w.setFindListener { _, count, done -> if (done) toast("Найдено: $count") }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                val u = r?.url ?: return false
                val sch = u.scheme ?: ""
                if (sch != "http" && sch != "https" && sch != "file") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { }
                    return true
                }
                if (on("https") && sch == "http" && r.isForMainFrame) {
                    open(w, "https://" + u.toString().removePrefix("http://")); return true
                }
                return false
            }
            override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                val h = r?.url?.host ?: return null
                if (on("trackers") && blocked(h)) {
                    blockedSession.incrementAndGet()
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun onPageFinished(v: WebView?, u: String?) {
                box.isRefreshing = false
                if (t === cur) urlBar.setText(shown(u))
                if (u == null || u.startsWith("file:")) return
                if (on("banners")) v?.evaluateJavascript(BANNER_JS, null)
                if (!t.incognito && u.startsWith("http")) addHistory(t.title, u)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(v: WebView?, title: String?) { t.title = title ?: t.title }
            override fun onShowCustomView(v: View?, cb: WebChromeClient.CustomViewCallback?) {
                if (v == null) return
                customView = v; customCb = cb
                v.setBackgroundColor(Color.BLACK)
                (window.decorView as FrameLayout).addView(v, FrameLayout.LayoutParams(-1, -1))
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            }
            override fun onHideCustomView() { exitFullscreen() }
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: WebChromeClient.FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { startActivityForResult(p!!.createIntent(), 88); true }
                catch (e: Exception) { fileCb = null; cb?.onReceiveValue(null); false }
            }
            override fun onPermissionRequest(r: PermissionRequest?) {
                if (r == null) return
                val cam = r.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val mic = r.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                if (!cam && !mic) { r.deny(); return }
                val what = listOfNotNull(if (cam) "камере" else null, if (mic) "микрофону" else null).joinToString(" и ")
                askPermission(r.origin.host ?: "Сайт", what) { ok ->
                    if (!ok) { r.deny(); return@askPermission }
                    val need = mutableListOf<String>()
                    if (cam) need.add(Manifest.permission.CAMERA)
                    if (mic) need.add(Manifest.permission.RECORD_AUDIO)
                    val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                    if (missing.isEmpty()) r.grant(r.resources)
                    else { pendingPerm = r; requestPermissions(missing.toTypedArray(), 99) }
                }
            }
            override fun onGeolocationPermissionsShowPrompt(origin: String?, cb: GeolocationPermissions.Callback?) {
                if (origin == null || cb == null) return
                askPermission(Uri.parse(origin).host ?: origin, "геолокации") { ok ->
                    if (!ok) { cb.invoke(origin, false, false); return@askPermission }
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                        cb.invoke(origin, true, false)
                    else { pendingGeo = origin to cb; requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 98) }
                }
            }
            override fun onProgressChanged(v: WebView?, p: Int) {
                if (t !== cur) return
                progress.progress = p
                progress.visibility = if (p < 100) View.VISIBLE else View.GONE
            }
        }
        tabs.add(t); applyPrefs()
        if (url != null) open(w, url) else w.loadUrl(home(incognito))
        select(t)
    }

    private fun select(t: Tab) {
        cur?.web?.let { if (it !== t.web && on("sleep")) it.onPause() }
        content.removeAllViews()
        content.addView(t.box, ViewGroup.LayoutParams(-1, -1))
        t.web.onResume()
        cur = t; progress.visibility = View.GONE
        urlBar.setText(shown(t.web.url)); countBtn.text = tabs.size.toString()
    }

    private fun closeTab(t: Tab) {
        val i = tabs.indexOf(t); tabs.remove(t); content.removeView(t.box)
        t.web.clearHistory(); t.web.destroy()
        if (t.incognito && tabs.none { it.incognito })
            Handler(Looper.getMainLooper()).postDelayed({ purge() }, 800)
        if (tabs.isEmpty()) newTab()
        else if (t === cur) select(tabs[maxOf(0, i - 1)])
        else countBtn.text = tabs.size.toString()
    }

    private fun closeAll() {
        val hadInc = tabs.any { it.incognito }
        tabs.forEach { content.removeView(it.box); it.web.clearHistory(); it.web.destroy() }
        tabs.clear(); cur = null
        if (hadInc) Handler(Looper.getMainLooper()).postDelayed({ purge() }, 800)
        newTab()
    }

    private fun openIncognito(url: String? = null) {
        pendingUrl = url
        if (pref("lock")) {
            val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
            val i = km.createConfirmDeviceCredentialIntent("Инкогнито", "Подтверди, что это ты")
            if (i != null) { startActivityForResult(i, 77); return }
        }
        newTab(url, true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 77 && res == RESULT_OK) newTab(pendingUrl, true)
        if (rc == 88) { fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); fileCb = null }
        if (rc == 55 && res == RESULT_OK)
            d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { go(it) }
    }

    private fun showTabs() {
        val dlg = AlertDialog.Builder(this, DIALOG).create()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val grid = GridLayout(this).apply { columnCount = 2 }
        tabs.forEach { t ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = round(if (t.incognito) INC else HI, 14)
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setOnClickListener { select(t); dlg.dismiss() }
            }
            card.addView(TextView(this).apply {
                text = (if (t.incognito) "🕶 " else "") + t.title; setTextColor(Color.WHITE)
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            })
            card.addView(TextView(this).apply {
                text = Uri.parse(t.web.url ?: "").host ?: ""; setTextColor(MUTED); textSize = 11f; setSingleLine()
            })
            card.addView(TextView(this).apply {
                text = "✕ закрыть"; setTextColor(MUTED); textSize = 12f; setPadding(0, dp(8), 0, 0)
                setOnClickListener { closeTab(t); dlg.dismiss(); showTabs() }
            })
            grid.addView(card, GridLayout.LayoutParams().apply { width = dp(140); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        col.addView(grid)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        row.addView(btn("＋") { dlg.dismiss(); newTab() })
        row.addView(btn("🕶") { dlg.dismiss(); openIncognito() })
        row.addView(btn("Закрыть все") { dlg.dismiss(); closeAll() }.apply { textSize = 14f })
        col.addView(row)
        dlg.setView(ScrollView(this).apply { addView(col) })
        dlg.show()
    }

    // ---------- навигация ----------
    private fun open(w: WebView, url: String) {
        if (on("dnt")) w.loadUrl(url, mapOf("DNT" to "1", "Sec-GPC" to "1")) else w.loadUrl(url)
    }

    private fun go(v: String) {
        val s = v.trim(); if (s.isEmpty()) return
        val base = if (engine() == "google") "https://www.google.com/search?q=" else "https://duckduckgo.com/?q="
        val u = when {
            Regex("^[\\w-]+://.*").matches(s) -> s
            Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/.*)?$").matches(s) -> "https://$s"
            else -> base + URLEncoder.encode(s, "UTF-8")
        }
        cur?.web?.let { open(it, u) }
        urlBar.clearFocus()
    }

    private fun applyPrefs() {
        val cm = CookieManager.getInstance()
        tabs.forEach {
            cm.setAcceptThirdPartyCookies(it.web, !on("cookies"))
            it.web.settings.textZoom = prefs.getInt("zoom", 100)
            it.web.settings.safeBrowsingEnabled = on("safe")
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING))
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(it.web.settings, pref("dark"))
        }
        shieldBtn.alpha = if (pref("shield")) 1f else 0.35f
    }

    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val r = DownloadManager.Request(Uri.parse(url))
            mime?.let { r.setMimeType(it) }; r.addRequestHeader("User-Agent", ua ?: "")
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            toast("Скачивание: $name")
        } catch (e: Exception) { toast("Не удалось скачать файл") }
    }

    // ---------- 5.0 ----------
    private fun linkMenu(u: String, image: Boolean) {
        val title = u.take(60)
        if (image) menu(title,
            mi("Сохранить картинку") { download(u, null, null, null) },
            mi("Открыть в новой вкладке") { newTab(u) },
            mi("Копировать адрес картинки") { copy(u) })
        else menu(title,
            mi("Открыть в новой вкладке") { newTab(u) },
            mi("Открыть в инкогнито") { openIncognito(u) },
            mi("Копировать ссылку") { copy(u) },
            mi("Поделиться") { shareText(u) })
    }

    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", s))
        toast("Скопировано")
    }

    private fun shareText(s: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, s) }
        startActivity(Intent.createChooser(i, "Поделиться"))
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        (window.decorView as FrameLayout).removeView(v)
        customView = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        customCb?.onCustomViewHidden(); customCb = null
    }

    private fun voice() {
        try {
            startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Говори, бро")
            }, 55)
        } catch (e: Exception) { toast("Голосовой ввод недоступен") }
    }

    private fun showZoom() {
        val z = listOf(80, 100, 125, 150, 200)
        AlertDialog.Builder(this, DIALOG).setTitle("Размер текста")
            .setSingleChoiceItems(arrayOf("Мелкий (80%)", "Обычный (100%)", "Крупный (125%)", "Очень крупный (150%)", "Огромный (200%)"),
                z.indexOf(prefs.getInt("zoom", 100)).coerceAtLeast(1)) { d, i ->
                prefs.edit().putInt("zoom", z[i]).apply(); applyPrefs(); d.dismiss()
            }.show()
    }

    private fun askPermission(host: String, what: String, onResult: (Boolean) -> Unit) {
        AlertDialog.Builder(this, DIALOG).setTitle(host).setMessage("Сайт просит доступ к $what. Разрешить?")
            .setPositiveButton("Разрешить") { _, _ -> onResult(true) }
            .setNegativeButton("Запретить") { _, _ -> onResult(false) }
            .setOnCancelListener { onResult(false) }.show()
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        val ok = res.isNotEmpty() && res.all { it == PackageManager.PERMISSION_GRANTED }
        if (rc == 99) {
            val r = pendingPerm; pendingPerm = null
            if (r != null) { if (ok) r.grant(r.resources) else r.deny() }
        }
        if (rc == 98) {
            val g = pendingGeo; pendingGeo = null
            if (g != null) g.second.invoke(g.first, ok, false)
        }
    }

    // ---------- меню ----------
    private fun showMenu() {
        menu("Bro Browser 5.0",
            mi("Добавить в закладки") { addBookmark() },
            mi("Закладки") { showList("bm", "Закладки") },
            mi("История") { showList("hist", "История") },
            mi("Найти на странице") { findDialog() },
            mi(if (cur?.desktop == true) "Мобильная версия" else "Версия для ПК") { toggleDesktop() },
            mi("Режим чтения") { cur?.web?.evaluateJavascript(READER_JS, null) },
            mi("Перевести на русский") { translate() },
            mi("Голосовой поиск") { voice() },
            mi("Поделиться") { share() },
            mi("Ещё…") { showMore() },
            mi("Настройки…") { showSettings() })
    }

    private fun showMore() {
        menu("Ещё",
            mi("Копировать ссылку") { copyLink() },
            mi("Сохранить как PDF") { savePdf() },
            mi("Скриншот страницы") { screenshot() },
            mi("Обновить страницу") { cur?.web?.reload() },
            mi("Размер текста") { showZoom() },
            mi("Загрузки") { try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) { } },
            mi("Экспорт закладок") { exportBm() },
            mi("Импорт закладок (из буфера)") { importBm() })
    }

    private fun showSettings() {
        menu("Настройки",
            mi("Защита и оптимизация") { showShield() },
            mi("Поисковик: " + engineName()) { showEngine() },
            mi("Тема оформления") { showTheme() },
            mi("Статистика") { showStats() },
            mi("Обновить списки блокировки") { updateLists() })
    }

    private fun addBookmark() {
        val t = cur ?: return
        val u = t.web.url ?: return
        if (u.startsWith("file:")) { toast("Сначала открой сайт"); return }
        val l = load("bm")
        if (l.none { it.second == u }) { l.add(0, t.title to u); save("bm", l) }
        toast("Добавлено в закладки")
    }

    private fun showList(key: String, title: String) {
        val l = load(key)
        val b = AlertDialog.Builder(this, DIALOG)
            .setTitle(if (l.isEmpty()) title else "$title (долгое нажатие — удалить)")
        if (l.isEmpty()) b.setMessage("Пока пусто")
        else b.setItems(l.map { it.first.ifBlank { it.second } }.toTypedArray()) { _, i ->
            cur?.web?.let { open(it, l[i].second) }
        }
        b.setNeutralButton("Очистить всё") { _, _ -> save(key, emptyList()) }
        if (key == "bm") b.setNegativeButton("А–Я") { _, _ -> save(key, l.sortedBy { it.first.lowercase() }) }
        b.setPositiveButton("Закрыть", null)
        val d = b.show()
        if (l.isNotEmpty()) d.listView.setOnItemLongClickListener { _, _, i, _ ->
            l.removeAt(i); save(key, l); d.dismiss(); showList(key, title); true
        }
    }

    private fun findDialog() {
        val et = EditText(this)
        AlertDialog.Builder(this, DIALOG).setTitle("Найти на странице").setView(et)
            .setPositiveButton("Найти") { _, _ -> cur?.web?.findAllAsync(et.text.toString()) }
            .setNeutralButton("Далее") { _, _ -> cur?.web?.findNext(true) }
            .setNegativeButton("Сбросить") { _, _ -> cur?.web?.clearMatches() }.show()
    }

    private fun toggleDesktop() {
        val t = cur ?: return
        t.desktop = !t.desktop
        t.web.settings.userAgentString = if (t.desktop) DESK else null
        t.web.settings.useWideViewPort = t.desktop
        t.web.settings.loadWithOverviewMode = t.desktop
        t.web.reload()
        toast(if (t.desktop) "Версия для ПК" else "Мобильная версия")
    }

    private fun translate() {
        val u = cur?.web?.url ?: return
        if (u.startsWith("file:")) return
        cur?.web?.let { open(it, "https://translate.google.com/translate?sl=auto&tl=ru&u=" + URLEncoder.encode(u, "UTF-8")) }
    }

    private fun share() {
        val u = cur?.web?.url ?: return
        if (u.startsWith("file:")) return
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, u) }
        startActivity(Intent.createChooser(i, "Поделиться"))
    }

    private fun copyLink() {
        val u = cur?.web?.url ?: return
        if (u.startsWith("file:")) return
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", u))
        toast("Ссылка скопирована")
    }

    private fun savePdf() {
        val w = cur?.web ?: return
        val name = (cur?.title ?: "page").take(40)
        (getSystemService(PRINT_SERVICE) as PrintManager)
            .print(name, w.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
        toast("Выбери «Сохранить как PDF»")
    }

    @SuppressLint("NewApi")
    private fun screenshot() {
        val w = cur?.web ?: return
        if (android.os.Build.VERSION.SDK_INT < 29) { toast("Нужен Android 10 или новее"); return }
        try {
            val bmp = Bitmap.createBitmap(w.width, w.height, Bitmap.Config.ARGB_8888)
            w.draw(Canvas(bmp))
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "bro_" + System.currentTimeMillis() + ".png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Bro")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("Скриншот сохранён в Pictures/Bro")
        } catch (e: Exception) { toast("Не удалось сохранить") }
    }

    private fun exportBm() {
        val a = JSONArray(); load("bm").forEach { a.put(JSONObject().put("t", it.first).put("u", it.second)) }
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, a.toString()) }
        startActivity(Intent.createChooser(i, "Экспорт закладок"))
    }

    private fun importBm() {
        try {
            val cb = (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val a = JSONArray(cb); val l = load("bm")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i); val u = o.getString("u")
                if (l.none { it.second == u }) l.add(o.getString("t") to u)
            }
            save("bm", l); toast("Импортировано, всего: " + l.size)
        } catch (e: Exception) { toast("Скопируй текст экспорта и повтори") }
    }

    private fun showStats() {
        val total = prefs.getLong("blocked", 0) + blockedSession.get()
        AlertDialog.Builder(this, DIALOG).setTitle("Статистика")
            .setMessage("Заблокировано запросов: $total\nЗа эту сессию: ${blockedSession.get()}\n" +
                "Доменов в списках: ${extra.size + bad.size}\nЗакладок: ${load("bm").size}\n" +
                "Записей в истории: ${load("hist").size}")
            .setPositiveButton("Ок", null).show()
    }

    private fun showTheme() {
        val ids = listOf("purple", "blue", "green", "black")
        AlertDialog.Builder(this, DIALOG).setTitle("Тема оформления")
            .setSingleChoiceItems(arrayOf("Фиолетовая", "Синяя", "Зелёная", "AMOLED чёрная"),
                ids.indexOf(prefs.getString("theme", "purple")).coerceAtLeast(0)) { d, i ->
                prefs.edit().putString("theme", ids[i]).apply()
                d.dismiss(); toast("Перезапусти приложение, чтобы применить тему")
            }.show()
    }

    private fun showEngine() {
        AlertDialog.Builder(this, DIALOG).setTitle("Поисковик")
            .setSingleChoiceItems(arrayOf("DuckDuckGo", "Google"), if (engine() == "google") 1 else 0) { d, i ->
                prefs.edit().putString("engine", if (i == 1) "google" else "ddg").apply()
                tabs.forEach { if (it.web.url?.startsWith("file:") == true) it.web.loadUrl(home(it.incognito)) }
                d.dismiss(); toast("Поисковик: " + engineName())
            }.show()
    }

    private fun showShield() {
        val checked = BooleanArray(keys.size) { pref(keys[it]) }
        AlertDialog.Builder(this, DIALOG).setTitle("Защита и оптимизация")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, v ->
                prefs.edit().putBoolean(keys[i], v).apply(); applyPrefs()
            }
            .setPositiveButton("Готово", null).show()
    }

    override fun onBackPressed() {
        if (customView != null) { exitFullscreen(); return }
        val w = cur?.web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}
