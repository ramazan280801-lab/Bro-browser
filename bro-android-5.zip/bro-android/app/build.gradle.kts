plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "app.bro.browser"
    compileSdk = 34
    defaultConfig { applicationId = "app.bro.browser"; minSdk = 26; targetSdk = 34; versionCode = 5; versionName = "5.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
