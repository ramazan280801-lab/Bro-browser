package app.bro.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import java.io.ByteArrayInputStream

class Tab(val web: WebView, var title: String = "Новая вкладка")

class MainActivity : Activity() {
    private val BG = Color.parseColor("#15101F")
    private val BAR = Color.parseColor("#1E1730")
    private val HI = Color.parseColor("#2B2145")
    private val MUTED = Color.parseColor("#9D93B8")
    private val tabs = mutableListOf<Tab>()
    private var cur: Tab? = null
    private lateinit var strip: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var urlBar: EditText
    private lateinit var shieldBtn: TextView
    private val prefs by lazy { getSharedPreferences("bro", MODE_PRIVATE) }
    private val keys = listOf("shield", "trackers", "https", "cookies", "dnt", "sleep", "safe")
    private val names = listOf(
        "Bro Shield (главный выключатель)", "Блокировка трекеров и рекламы", "Только HTTPS",
        "Блокировать сторонние cookies", "Не отслеживать (DNT)", "Спящие вкладки", "Безопасный просмотр"
    )
    private val bad = listOf(
        "doubleclick.net", "google-analytics.com", "googletagmanager.com", "googlesyndication.com",
        "connect.facebook.net", "adservice.google.com", "scorecardresearch.com", "hotjar.com", "criteo.com",
        "taboola.com", "outbrain.com", "adnxs.com", "amazon-adsystem.com", "mc.yandex.ru"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun on(k: String) = prefs.getBoolean("shield", true) && prefs.getBoolean(k, true)
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun btn(t: String, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); fitsSystemWindows = true }
        strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })
        urlBar = EditText(this).apply {
            hint = "Поиск или адрес"; setHintTextColor(MUTED); setTextColor(Color.WHITE); textSize = 15f
            setSingleLine(); background = round(HI, 20); setPadding(dp(16), 0, dp(16), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); true }
        }
        shieldBtn = btn("🛡") {
            val v = !prefs.getBoolean("shield", true)
            prefs.edit().putBoolean("shield", v).apply(); applyPrefs()
            Toast.makeText(this, if (v) "Bro Shield включён" else "Bro Shield выключен", Toast.LENGTH_SHORT).show()
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(BAR); setPadding(dp(4), dp(6), dp(4), dp(6)) }
        bar.addView(btn("←") { cur?.web?.let { if (it.canGoBack()) it.goBack() } })
        bar.addView(btn("⟳") { cur?.web?.reload() })
        bar.addView(urlBar, LinearLayout.LayoutParams(0, dp(42), 1f))
        bar.addView(shieldBtn)
        bar.addView(btn("⚙") { showSettings() })
        root.addView(bar)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        newTab(intent?.dataString)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String? = null) {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.setBackgroundColor(BG)
        val t = Tab(w)
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                val u = r?.url?.toString() ?: return false
                if (on("https") && u.startsWith("http://") && r.isForMainFrame) {
                    open(w, "https://" + u.removePrefix("http://")); return true
                }
                return false
            }
            override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? {
                val h = r?.url?.host ?: return null
                if (on("trackers") && bad.any { h == it || h.endsWith(".$it") })
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                return null
            }
            override fun onPageFinished(v: WebView?, u: String?) {
                if (t === cur) urlBar.setText(shown(u))
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(v: WebView?, title: String?) { t.title = title ?: t.title; drawTabs() }
        }
        tabs.add(t); applyPrefs()
        if (url != null) open(w, url) else w.loadUrl("file:///android_asset/newtab.html")
        select(t)
    }

    private fun shown(u: String?) = if (u == null || u.startsWith("file:")) "" else u

    private fun select(t: Tab) {
        cur?.web?.let { if (it !== t.web && on("sleep")) it.onPause() }
        content.removeAllViews()
        content.addView(t.web, ViewGroup.LayoutParams(-1, -1))
        t.web.onResume()
        cur = t; urlBar.setText(shown(t.web.url)); drawTabs()
    }

    private fun closeTab(t: Tab) {
        val i = tabs.indexOf(t); tabs.remove(t); content.removeView(t.web); t.web.destroy()
        if (tabs.isEmpty()) newTab() else if (t === cur) select(tabs[maxOf(0, i - 1)]) else drawTabs()
    }

    private fun drawTabs() {
        strip.removeAllViews()
        tabs.forEach { t ->
            strip.addView(TextView(this).apply {
                text = t.title; setTextColor(if (t === cur) Color.WHITE else MUTED)
                maxWidth = dp(150); setSingleLine(); ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(14), dp(10), dp(14), dp(10))
                if (t === cur) background = round(BAR, 12)
                setOnClickListener { select(t) }
                setOnLongClickListener { closeTab(t); true }
            })
        }
        strip.addView(btn("+") { newTab() })
    }

    private fun open(w: WebView, url: String) {
        if (on("dnt")) w.loadUrl(url, mapOf("DNT" to "1", "Sec-GPC" to "1")) else w.loadUrl(url)
    }

    private fun go(v: String) {
        val s = v.trim(); if (s.isEmpty()) return
        val u = when {
            Regex("^[\\w-]+://.*").matches(s) -> s
            Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?(/.*)?$").matches(s) -> "https://$s"
            else -> "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(s, "UTF-8")
        }
        cur?.web?.let { open(it, u) }
        urlBar.clearFocus()
    }

    private fun applyPrefs() {
        val cm = CookieManager.getInstance()
        tabs.forEach {
            cm.setAcceptThirdPartyCookies(it.web, !on("cookies"))
            it.web.settings.safeBrowsingEnabled = on("safe")
        }
        shieldBtn.alpha = if (prefs.getBoolean("shield", true)) 1f else 0.35f
    }

    private fun showSettings() {
        val checked = BooleanArray(keys.size) { prefs.getBoolean(keys[it], true) }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Настройки Bro")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, i, v ->
                prefs.edit().putBoolean(keys[i], v).apply(); applyPrefs()
            }
            .setPositiveButton("Готово", null).show()
    }

    override fun onBackPressed() {
        val w = cur?.web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}
